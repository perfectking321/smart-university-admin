import React, { useState, useRef, useEffect } from 'react';
import { Bot, Database, Send, Sparkles, User, ChevronDown, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatMessage, QueryResult } from './types';
import { MOCK_STUDENTS, MOCK_DEPARTMENTS } from './constants';
import { generateSQL } from './services/geminiService';
import { SQLDisplay } from './components/SQLDisplay';
import { ResultsTable } from './components/ResultsTable';

export default function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'dbms'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hey! Admin, What can I help with?',
    }
  ]);
  const [latestResult, setLatestResult] = useState<{ sql?: string; results?: QueryResult } | null>(null);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI processing
    const { sql, explanation } = await generateSQL(input);
    
    // Simulate "executing" SQL on mock data
    let results: QueryResult = { columns: [], rows: [] };
    if (sql.toLowerCase().includes('students')) {
      results = {
        columns: ['NAME', 'ROLL_NUMBER', 'ATTENDANCE_PERCENTAGE'],
        rows: MOCK_STUDENTS.slice(0, 4).map(s => ({
          NAME: s.name,
          ROLL_NUMBER: s.roll_number,
          ATTENDANCE_PERCENTAGE: s.attendance_percentage.toFixed(1)
        }))
      };
    } else if (sql.toLowerCase().includes('departments')) {
      results = {
        columns: ['NAME', 'HEAD'],
        rows: MOCK_DEPARTMENTS.map(d => ({
          NAME: d.name,
          HEAD: d.head
        }))
      };
    }

    const statusContent = results.rows.length > 0 
      ? `Query executed successfully! Found ${results.rows.length} rows.`
      : explanation;

    const assistantMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: statusContent,
    };

    setMessages(prev => [...prev, assistantMessage]);
    setLatestResult({ sql, results });
    setIsTyping(false);
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-black text-zinc-100">
      {/* Video Background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="video-background"
      >
        <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-connections-background-34412-large.mp4" type="video/mp4" />
      </video>
      <div className="video-overlay" />

      {/* Sidebar */}
      <aside className="flex w-16 flex-col items-center border-r border-white/5 bg-black/20 py-6 backdrop-blur-md">
        <div className="mb-10 flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500 text-white shadow-[0_0_20px_rgba(6,182,212,0.4)]">
          <LayoutGrid size={24} />
        </div>
        
        <nav className="flex flex-col gap-6">
          <button
            onClick={() => setActiveTab('chat')}
            className={`group relative flex h-10 w-10 items-center justify-center rounded-lg transition-all ${
              activeTab === 'chat' ? 'bg-white/10 text-cyan-400' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Bot size={22} />
            {activeTab === 'chat' && (
              <motion.div
                layoutId="active-nav"
                className="absolute -left-0.5 h-6 w-1 rounded-r-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
              />
            )}
          </button>
          
          <button
            onClick={() => setActiveTab('dbms')}
            className={`group relative flex h-10 w-10 items-center justify-center rounded-lg transition-all ${
              activeTab === 'dbms' ? 'bg-white/10 text-cyan-400' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Database size={22} />
            {activeTab === 'dbms' && (
              <motion.div
                layoutId="active-nav"
                className="absolute -left-0.5 h-6 w-1 rounded-r-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
              />
            )}
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex flex-1 flex-col overflow-hidden bg-transparent">
        {/* Header */}
        <header className="flex h-16 items-center justify-between border-b border-white/5 px-8 bg-black/10 backdrop-blur-sm">
          <h1 className="text-lg font-medium text-zinc-200 tracking-tight">Smart University Admin</h1>
        </header>

        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {activeTab === 'chat' ? (
              <motion.div
                key="chat"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex h-full flex-col"
              >
                {/* Immersive Content Area */}
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-12 space-y-12 scrollbar-hide pb-40">
                  <div className="grid grid-cols-2 gap-12 max-w-7xl mx-auto w-full">
                    {/* Left Column: Chat History */}
                    <div className="space-y-8">
                      {messages.length === 1 && (
                        <div className="space-y-8">
                          <h2 className="text-5xl font-light text-zinc-400 leading-tight">
                            Hey! Admin,<br />
                            <span className="text-zinc-100">What can I help with?</span>
                          </h2>
                          <div className="rounded-2xl bg-black/40 border border-white/10 p-6 max-w-md backdrop-blur-xl">
                            <div className="flex items-center gap-2 text-cyan-400/80 mb-4">
                              <Sparkles size={16} />
                              <span className="text-xs font-semibold uppercase tracking-wider">AI Assistant</span>
                            </div>
                            <ul className="space-y-3 text-sm text-zinc-400">
                              <li className="hover:text-cyan-300 cursor-pointer transition-colors">• Show all students in Computer Science</li>
                              <li className="hover:text-cyan-300 cursor-pointer transition-colors">• What is the average GPA by department?</li>
                              <li className="hover:text-cyan-300 cursor-pointer transition-colors">• List students with attendance below 75%</li>
                            </ul>
                          </div>
                        </div>
                      )}

                      <div className="space-y-6">
                        {messages.map((msg) => (
                          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className="flex items-start gap-3 max-w-[90%]">
                              {msg.role === 'assistant' && (
                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-cyan-400 border border-white/5">
                                  <Bot size={18} />
                                </div>
                              )}
                              <div className={`rounded-2xl px-5 py-3 shadow-lg backdrop-blur-xl ${
                                msg.role === 'user' 
                                  ? 'bg-cyan-600/20 border border-cyan-500/30 text-cyan-50' 
                                  : 'bg-black/60 border border-white/10 text-zinc-200'
                              }`}>
                                {msg.content}
                              </div>
                            </div>
                          </div>
                        ))}
                        {isTyping && (
                          <div className="flex items-center gap-2 text-cyan-500/50 ml-11">
                            <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-500/50" />
                            <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-500/50 [animation-delay:0.2s]" />
                            <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-500/50 [animation-delay:0.4s]" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right Column: Results */}
                    <div className="space-y-8">
                      {latestResult ? (
                        <motion.div
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-8 sticky top-0"
                        >
                          {latestResult.sql && (
                            <div className="space-y-3">
                              <h3 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Generated SQL Query</h3>
                              <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/40 backdrop-blur-xl">
                                <SQLDisplay sql={latestResult.sql} />
                              </div>
                            </div>
                          )}
                          
                          {latestResult.results && latestResult.results.rows.length > 0 && (
                            <div className="space-y-3">
                              <h3 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Query Results</h3>
                              <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/40 backdrop-blur-xl">
                                <ResultsTable columns={latestResult.results.columns} rows={latestResult.results.rows} />
                              </div>
                            </div>
                          )}
                        </motion.div>
                      ) : (
                        <div className="flex h-full items-center justify-center text-zinc-600 italic text-sm border border-dashed border-white/5 rounded-3xl bg-black/10 backdrop-blur-sm">
                          Query results will appear here
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Full-Width Chat Input */}
                <div className="absolute bottom-8 left-12 right-12">
                  <div className="mx-auto max-w-7xl">
                    <div className="relative rounded-2xl border border-white/10 bg-black/60 p-2 shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-3xl">
                      <div className="flex items-center gap-2 px-4 py-3">
                        <Sparkles size={20} className="text-cyan-500/50" />
                        <input
                          value={input}
                          onChange={(e) => setInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                          placeholder="Ask me anything about the university database..."
                          className="flex-1 bg-transparent text-zinc-200 placeholder:text-zinc-600 focus:outline-none text-lg"
                        />
                        <button
                          onClick={handleSend}
                          disabled={!input.trim()}
                          className="flex h-11 items-center gap-2 rounded-xl bg-cyan-600 px-6 text-sm font-semibold text-white transition-all hover:bg-cyan-500 disabled:opacity-50 disabled:hover:bg-cyan-600 shadow-[0_0_20px_rgba(8,145,178,0.3)]"
                        >
                          Send
                          <Send size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="dbms"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex h-full flex-col p-8 overflow-y-auto scrollbar-hide"
              >
                <div className="mx-auto w-full max-w-5xl space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-bold tracking-tight text-zinc-100">DBMS Demo</h2>
                    <p className="text-zinc-500">Explore database concepts and query execution</p>
                  </div>

                  <div className="flex flex-wrap justify-center gap-2">
                    {['Constraints', 'Aggregate Functions', 'Set Operations', 'Joins', 'Subqueries', 'Views', 'Triggers'].map((cat) => (
                      <button
                        key={cat}
                        className="rounded-full border border-white/10 bg-black/40 px-4 py-1.5 text-xs font-medium text-zinc-400 transition-all hover:border-cyan-500/50 hover:text-cyan-400 backdrop-blur-md"
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-6">
                    <div className="rounded-2xl border border-white/10 bg-black/40 p-6 space-y-4 backdrop-blur-xl">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-medium text-zinc-300">Constraint Catalog Lookup</h3>
                        <span className="text-xs text-zinc-500">information_schema.table_constraints</span>
                      </div>
                      <SQLDisplay sql={`SELECT *\n  FROM information_schema.table_constraints\n WHERE constraint_schema = 'public';`} />
                    </div>

                    <div className="rounded-2xl border border-white/10 bg-black/40 p-6 space-y-4 backdrop-blur-xl">
                      <h3 className="text-sm font-medium text-zinc-300">Query Results</h3>
                      <ResultsTable
                        columns={['CONSTRAINT_NAME', 'CONSTRAINT_TYPE', 'TABLE_NAME']}
                        rows={[
                          { CONSTRAINT_NAME: 'attendance_student_id_fkey', CONSTRAINT_TYPE: 'FOREIGN KEY', TABLE_NAME: 'attendance' },
                          { CONSTRAINT_NAME: 'attendance_pkey', CONSTRAINT_TYPE: 'PRIMARY KEY', TABLE_NAME: 'attendance' },
                          { CONSTRAINT_NAME: 'students_roll_number_key', CONSTRAINT_TYPE: 'UNIQUE', TABLE_NAME: 'students' },
                        ]}
                      />
                      <div className="flex justify-end">
                        <span className="rounded bg-white/5 px-2 py-1 text-[10px] font-medium text-zinc-500">3 rows returned</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
